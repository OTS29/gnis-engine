import { NextResponse } from 'next/server';

export const runtime = 'nodejs';

export async function POST() {
  const res = NextResponse.json({ ok: true });
  res.cookies.set('gnis_session', '', { path: '/', maxAge: 0, httpOnly: true, sameSite: 'lax', secure: true });
  return res;
}
