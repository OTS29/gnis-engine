'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { logout } from '@/app/auth/action';
import SiteRenderer from '@/components/SiteRenderer';
import { TEMPLATE_LIST, ACCENTS, DEFAULT_DATA, BOOKING_STATUSES, ORDER_STATUSES, CURRENCIES, STRIPE_CURRENCIES, LANGUAGES, mergeData, formatMoney } from '@/lib/siteDefaults';
import { PROFESSIONS } from '@/lib/professions';

const TABS = [
  { id: 'design', l: 'Design' },
  { id: 'services', l: 'Services' },
  { id: 'products', l: 'Products' },
  { id: 'gallery', l: 'Gallery' },
  { id: 'analytics', l: 'Analytics' },
  { id: 'bookings', l: 'Bookings' },
  { id: 'orders', l: 'Orders' },
  { id: 'staff', l: 'Staff' },
  { id: 'growth', l: 'Growth' },
  { id: 'payments', l: 'Payments' },
  { id: 'billing', l: 'Billing' },
];

const STATUS_COLOR = { pending: '#d97706', approved: '#2563eb', completed: '#059669', paid: '#059669', fulfilled: '#2563eb', cancelled: '#dc2626', no_show: '#7f1d1d' };
const RISK_COLOR = { low: '#059669', medium: '#d97706', high: '#dc2626' };

function Bars({ items, color = '#2563eb', fmt = (v) => v }) {
  const max = Math.max(1, ...items.map((i) => i.n));
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 3, height: 110 }}>
      {items.map((i) => (
        <div key={i.label} title={`${i.label}: ${fmt(i.n)}`} style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-end', height: '100%' }}>
          <div style={{ width: '100%', background: color, borderRadius: '3px 3px 0 0', height: `${Math.max(2, (i.n / max) * 90)}%`, opacity: i.n ? 1 : 0.2 }} />
          <div style={{ fontSize: 9, color: '#6b7280', marginTop: 3, whiteSpace: 'nowrap', overflow: 'hidden' }}>{i.label.length > 5 ? i.label.slice(0, 2) : i.label}</div>
        </div>
      ))}
    </div>
  );
}

function Line({ points, color = '#059669' }) {
  const w = 600, h = 120, max = Math.max(1, ...points.map((p) => p.v));
  const pts = points.map((p, i) => `${(i / Math.max(1, points.length - 1)) * w},${h - (p.v / max) * (h - 8) - 4}`).join(' ');
  return (
    <svg viewBox={`0 0 ${w} ${h}`} width="100%" height="120" preserveAspectRatio="none" role="img" aria-label="Revenue over 30 days">
      <polyline fill="none" stroke={color} strokeWidth="2.5" strokeLinejoin="round" points={pts} vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

function compress(file, max = 900, q = 0.7) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onerror = reject;
    r.onload = () => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const k = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL('image/jpeg', q));
      };
      img.src = r.result;
    };
    r.readAsDataURL(file);
  });
}

async function uploadDataUrl(dataUrl) {
  const blob = await (await fetch(dataUrl)).blob();
  const fd = new FormData();
  fd.append('file', blob, 'photo.jpg');
  const r = await fetch('/api/site/upload', { method: 'POST', body: fd });
  const j = await r.json();
  if (!j.ok) throw new Error(j.error || 'Upload failed');
  return j.url;
}
const isData = (v) => typeof v === 'string' && v.startsWith('data:image/');

const getJson = async (url) => { try { const r = await fetch(url); return await r.json(); } catch { return { ok: false }; } };
const sendJson = async (url, method, body) => {
  try { const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }); return await r.json(); } catch { return { ok: false, error: 'Network error' }; }
};

export default function Dashboard() {
  const [tab, setTab] = useState('design');
  const [template, setTemplate] = useState('classic');
  const [data, setData] = useState(mergeData(DEFAULT_DATA));
  const [slug, setSlug] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [orders, setOrders] = useState([]);
  const [staff, setStaff] = useState({ staff: [], shifts: [] });
  const [newStaff, setNewStaff] = useState('');
  const [analytics, setAnalytics] = useState(null);
  const [growth, setGrowth] = useState(null);
  const [qr, setQr] = useState('');
  const [payInfo, setPayInfo] = useState(null);
  const [payForm, setPayForm] = useState({ provider: '', bankCode: '', accountNumber: '', accountName: '', busy: false, msg: '', ok: false });
  const [banks, setBanks] = useState([]);
  const [stripeCountry, setStripeCountry] = useState('GB');
  const [billing, setBilling] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [plan, setPlan] = useState('starter');
  const [cycle, setCycle] = useState('monthly');
  const [billMsg, setBillMsg] = useState('');
  const [stripe, setStripe] = useState({ connected: false, ready: false, configured: true });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const [copied, setCopied] = useState(false);
  const fileRef = useRef(null);
  const target = useRef(null);

  const loadStaff = async () => { const j = await getJson('/api/site/staff'); if (j.ok) setStaff({ staff: j.staff, shifts: j.shifts }); };
  const loadAnalytics = async () => { const j = await getJson('/api/site/analytics'); if (j.ok) setAnalytics(j.data || null); };
  const loadGrowth = async () => { const j = await getJson('/api/site/growth'); if (j.ok) setGrowth(j.data || null); };
  const loadPay = async () => { const j = await getJson('/api/site/pay-setup'); if (j.ok) setPayInfo(j); };
  const loadBilling = async (r) => { const j = await getJson('/api/billing' + (r ? `?region=${encodeURIComponent(r)}` : '')); if (j.ok) setBilling(j); };
  const pickRegion = (code) => {
    try { localStorage.setItem('gnis_region', code); } catch {}
    setBilling(null);
    loadBilling(code);
  };
  const chooseProvider = async (provider) => {
    setPayForm({ provider, bankCode: '', accountNumber: '', accountName: '', busy: true, msg: '', ok: false });
    setBanks([]);
    const j = await getJson(`/api/site/pay-setup?provider=${provider}&banks=1`);
    if (j.ok) { setBanks(j.banks || []); setPayForm((f) => ({ ...f, busy: false })); }
    else setPayForm((f) => ({ ...f, busy: false, msg: j.error || 'Could not load banks' }));
  };
  const verifyAccount = async () => {
    setPayForm((f) => ({ ...f, busy: true, msg: '', accountName: '' }));
    const j = await sendJson('/api/site/pay-setup', 'POST', { provider: payForm.provider, bankCode: payForm.bankCode, accountNumber: payForm.accountNumber });
    setPayForm((f) => ({ ...f, busy: false, accountName: j.accountName || '', ok: !!j.accountName, msg: j.accountName ? '' : 'Could not confirm the account name automatically. You can still save if the details are right.' }));
  };
  const savePayout = async () => {
    setPayForm((f) => ({ ...f, busy: true, msg: '' }));
    const j = await sendJson('/api/site/pay-setup', 'PUT', { provider: payForm.provider, bankCode: payForm.bankCode, accountNumber: payForm.accountNumber });
    if (j.ok) { setPayForm({ provider: '', bankCode: '', accountNumber: '', accountName: '', busy: false, msg: '', ok: false }); loadPay(); }
    else setPayForm((f) => ({ ...f, busy: false, ok: false, msg: j.error || 'Could not save' }));
  };
  const turnOffCards = async () => { await sendJson('/api/site/pay-setup', 'DELETE', {}); loadPay(); };
  const startPlan = async (plan) => {
    setBillMsg('Opening payment page…');
    const j = await sendJson('/api/billing', 'POST', { plan, cycle, region: billing?.region });
    if (j.ok && j.url) window.location.href = j.url; else setBillMsg(j.error || 'Could not start payment');
  };
  const loadStripe = async () => { const j = await getJson('/api/site/stripe'); if (j.ok) setStripe({ connected: j.connected, ready: j.ready, configured: j.configured }); };

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch('/api/site');
        if (r.status === 401) { window.location.href = '/'; return; }
        const j = await r.json();
        if (j.plan) setPlan(j.plan);
        if (j.data) { setTemplate(j.data.template || 'classic'); setData(mergeData(j.data.data)); setSlug(j.data.slug); }
        const [b, o] = await Promise.all([getJson('/api/site/bookings'), getJson('/api/site/orders')]);
        if (b.ok) setBookings(b.data || []);
        if (o.ok) setOrders(o.data || []);
        if (j.data) { loadStaff(); loadStripe(); loadAnalytics(); loadGrowth(); loadPay(); }
        let savedRegion = '';
        try { savedRegion = localStorage.getItem('gnis_region') || ''; } catch {}
        loadBilling(savedRegion);
        getJson('/api/users/get').then((u) => { if (u?.ok && u.data?.role === 'admin') setIsAdmin(true); });
        const qs = new URLSearchParams(window.location.search);
        if (qs.get('stripe') === 'done') setTab('payments');
        if (qs.get('tab') === 'billing') {
          setTab('billing');
          if (qs.get('plan') === 'done') setBillMsg('Payment received. Your plan updates within a minute.');
          if (qs.get('plan') === 'failed') setBillMsg('We could not confirm that payment. If you were charged, contact support.');
        }
      } catch {}
      setLoading(false);
    })();
  }, []);

  const cur = data.currency || 'GBP';
  const sym = (formatMoney(0, cur, data.language || 'en').replace(/[0-9.,\s]/g, '')) || cur;
  const CC = { GBP: '44', NGN: '234', GHS: '233', KES: '254', ZAR: '27', USD: '1', CAD: '1', AUD: '61', EUR: '353' };
  const waLink = (b) => {
    const raw = String(b.contact || '');
    if (raw.includes('@')) return null;
    let d = raw.replace(/[^\d+]/g, '');
    if (d.startsWith('+')) d = d.slice(1);
    else if (d.startsWith('00')) d = d.slice(2);
    else if (d.startsWith('0')) d = (CC[cur] || '44') + d.slice(1);
    if (!/^\d{10,15}$/.test(d)) return null;
    const text = b.status === 'approved'
      ? `Hi ${b.customer}, a reminder of your ${b.service} booking with ${data.businessName} on ${b.date} at ${b.time}. See you then!`
      : `Hi ${b.customer}, thanks for booking ${b.service} with ${data.businessName} on ${b.date} at ${b.time}. Does that time still suit you?`;
    return `https://wa.me/${d}?text=${encodeURIComponent(text)}`;
  };
  const fm = (n) => formatMoney(Math.round((Number(n) || 0) * 100) / 100, cur, data.language || 'en');
  const set = (k, v) => setData((d) => ({ ...d, [k]: v }));
  const setItem = (k, i, patch) => setData((d) => ({ ...d, [k]: d[k].map((x, j) => (j === i ? { ...x, ...patch } : x)) }));
  const addItem = (k, item) => setData((d) => ({ ...d, [k]: [...d[k], item] }));
  const delItem = (k, i) => setData((d) => ({ ...d, [k]: d[k].filter((_, j) => j !== i) }));

  const sizeKB = useMemo(() => Math.round(JSON.stringify(data).length / 1024), [data]);
  const tooBig = sizeKB > 3800;

  const pick = (kind, idx) => { target.current = { kind, idx }; fileRef.current?.click(); };
  const onFile = async (e) => {
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    if (!files.length) return;
    const { kind, idx } = target.current || {};
    try {
      if (kind === 'gallery') {
        const imgs = [];
        setMsg('Uploading…');
        for (const f of files.slice(0, 12 - data.gallery.length)) imgs.push(await uploadDataUrl(await compress(f, 1200)));
        setData((d) => ({ ...d, gallery: [...d.gallery, ...imgs].slice(0, 12) }));
      } else if (kind === 'hero') { setMsg('Uploading…'); set('hero', await uploadDataUrl(await compress(files[0], 1920, 0.78))); }
      else if (kind === 'product') { setMsg('Uploading…'); setItem('products', idx, { image: await uploadDataUrl(await compress(files[0], 900)) }); }
      setMsg('Photo uploaded. Press Save to publish.');
    } catch (err) { setMsg(err.message || 'Could not upload that image'); }
  };

  const save = async () => {
    setSaving(true); setMsg('');
    let toSave = data;
    try {
      // Move any old in-database photos to image storage so the site loads fast.
      const swap = async (v) => (isData(v) ? await uploadDataUrl(v) : v);
      const needs = isData(data.hero) || data.gallery.some(isData) || data.products.some((p) => isData(p.image));
      if (needs) {
        setMsg('Optimising photos…');
        toSave = {
          ...data,
          hero: await swap(data.hero),
          gallery: await Promise.all(data.gallery.map(swap)),
          products: await Promise.all(data.products.map(async (p) => ({ ...p, image: await swap(p.image) }))),
        };
        setData(toSave);
      }
    } catch (err) { setMsg(err.message || 'Photo upload failed'); setSaving(false); return; }
    const j = await sendJson('/api/site', 'PUT', { template, data: toSave });
    if (j.ok) { const first = !slug; setSlug(j.slug); setMsg('Saved ✓ (live page updates within a minute at most)'); if (first) { loadStaff(); loadStripe(); } } else setMsg(j.error || 'Save failed');
    setSaving(false);
  };

  const setBookingStatus = async (id, status) => {
    setBookings((bs) => bs.map((b) => (b.id === id ? { ...b, status } : b)));
    await sendJson('/api/site/bookings', 'PUT', { id, status });
  };
  const setOrderStatus = async (id, status) => {
    setOrders((os) => os.map((o) => (o.id === id ? { ...o, status } : o)));
    await sendJson('/api/site/orders', 'PUT', { id, status });
  };

  const addStaff = async () => {
    const j = await sendJson('/api/site/staff', 'POST', { name: newStaff });
    if (j.ok) { setNewStaff(''); loadStaff(); } else setMsg(j.error || 'Could not add staff');
  };
  const newCode = async (id) => { await sendJson('/api/site/staff', 'PATCH', { id }); loadStaff(); };
  const removeStaff = async (id) => { if (confirm('Remove this staff member?')) { await sendJson('/api/site/staff', 'DELETE', { id }); loadStaff(); } };

  const makeQr = async () => {
    try {
      const QR = (await import('qrcode')).default;
      setQr(await QR.toDataURL(liveUrl, { width: 600, margin: 2 }));
    } catch { setMsg('Could not make the QR code'); }
  };

  const connectStripe = async () => {
    const j = await sendJson('/api/site/stripe', 'POST', { country: stripeCountry });
    if (j.ok && j.url) window.location.href = j.url; else setMsg(j.error || 'Could not start Stripe setup');
  };

  const liveUrl = slug && typeof window !== 'undefined' ? `${window.location.origin}/site/${slug}` : '';
  const clockUrl = slug && typeof window !== 'undefined' ? `${window.location.origin}/clock/${slug}` : '';
  const copy = async (text) => { try { await navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch {} };

  const box = { background: '#fff', border: '1px solid #e5e7eb', borderRadius: 12, padding: 16, marginBottom: 14 };
  const inp = { width: '100%', padding: '10px 12px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 15, boxSizing: 'border-box', marginBottom: 8 };
  const btn = (bg = '#111827') => ({ background: bg, color: '#fff', border: 0, padding: '10px 16px', borderRadius: 8, fontWeight: 600, cursor: 'pointer', fontSize: 14 });
  const sm = (bg) => ({ ...btn(bg), padding: '6px 10px', fontSize: 12 });
  const lbl = { fontSize: 12, fontWeight: 600, color: '#6b7280', display: 'block', margin: '4px 0' };
  const pill = (s) => ({ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', color: '#fff', background: STATUS_COLOR[s] || '#6b7280', padding: '2px 8px', borderRadius: 999 });

  if (loading) return <div style={{ padding: 40, fontFamily: 'system-ui' }}>Loading…</div>;

  const needSave = (
    <div style={box}>Save your site first (press <strong>Save</strong> at the top). Then this section will work.</div>
  );

  return (
    <div className="dash" style={{ fontFamily: 'system-ui, sans-serif', background: '#f3f4f6', color: '#111827', colorScheme: 'light', minHeight: '100vh', maxWidth: '100vw', overflowX: 'hidden' }}>
      <style>{`
        .dash{color-scheme:light;-webkit-text-size-adjust:100%}
        .dash input:not([type=checkbox]):not([type=file]),.dash textarea,.dash select{color:#111827 !important;background:#ffffff !important;-webkit-text-fill-color:#111827;font-size:16px !important;color-scheme:light;-webkit-appearance:none;appearance:none}
        .dash input[type=checkbox]{width:18px;height:18px;accent-color:#2563eb}
        .dash input::placeholder,.dash textarea::placeholder{color:#9ca3af !important;-webkit-text-fill-color:#9ca3af}
        .dash *{min-width:0}
        .dash img{max-width:100%}
      `}</style>
      <input ref={fileRef} type="file" accept="image/*" multiple hidden onChange={onFile} />
      <div style={{ background: '#fff', borderBottom: '1px solid #e5e7eb', padding: '12px 16px', display: 'flex', flexWrap: 'wrap', gap: 10, alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 5 }}>
        <strong>My site</strong>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <span style={{ fontSize: 12, color: tooBig ? '#dc2626' : '#6b7280' }}>{sizeKB} KB / 3800</span>
          {msg && <span style={{ fontSize: 13 }}>{msg}</span>}
          {isAdmin && <a href="/admin" style={{ fontSize: 14, color: '#7c3aed', fontWeight: 600 }}>Admin console</a>}
          {slug && <a href={`/site/${slug}`} target="_blank" rel="noreferrer" style={{ fontSize: 14, color: '#2563eb' }}>View live site ↗</a>}
          <button style={btn('#2563eb')} onClick={save} disabled={saving || tooBig}>{saving ? 'Saving…' : 'Save'}</button>
          <form action={logout}><button style={btn('#6b7280')}>Log out</button></form>
        </div>
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 16, padding: 16, maxWidth: 1400, margin: '0 auto' }}>
        <div style={{ flex: '1 1 440px', minWidth: 0 }}>
          {slug && (
            <div style={{ ...box, display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
              <span style={{ fontSize: 13, color: '#6b7280' }}>Your link:</span>
              <code style={{ fontSize: 13, wordBreak: 'break-all', flex: '1 1 200px' }}>{liveUrl}</code>
              <button style={sm('#374151')} onClick={() => copy(liveUrl)}>{copied ? 'Copied ✓' : 'Copy'}</button>
              <a style={{ ...sm('#25d366'), textDecoration: 'none' }} target="_blank" rel="noreferrer" href={`https://wa.me/?text=${encodeURIComponent(`Book with ${data.businessName}: ${liveUrl}`)}`}>WhatsApp</a>
            </div>
          )}

          <div style={{ display: 'flex', gap: 6, marginBottom: 14, flexWrap: 'wrap' }}>
            {TABS.map((x) => (
              <button key={x.id} onClick={() => setTab(x.id)} style={{ ...btn(tab === x.id ? '#111827' : '#fff'), color: tab === x.id ? '#fff' : '#111827', border: '1px solid #e5e7eb', whiteSpace: 'nowrap' }}>
                {x.l}{x.id === 'bookings' && bookings.filter((b) => b.status === 'pending').length ? ` (${bookings.filter((b) => b.status === 'pending').length})` : ''}{x.id === 'orders' && orders.filter((o) => o.status === 'pending' || o.status === 'paid').length ? ` (${orders.filter((o) => o.status === 'pending' || o.status === 'paid').length})` : ''}
              </button>
            ))}
          </div>

          {tab === 'design' && (<>
            <div style={box}>
              <strong>Template</strong>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(110px,1fr))', gap: 8, marginTop: 10 }}>
                {TEMPLATE_LIST.map((t) => (
                  <button key={t.id} onClick={() => setTemplate(t.id)} style={{ textAlign: 'left', padding: 10, borderRadius: 10, cursor: 'pointer', border: template === t.id ? '2px solid #2563eb' : '1px solid #d1d5db', background: template === t.id ? '#eff6ff' : '#fff' }}>
                    <div style={{ fontWeight: 600, fontSize: 14 }}>{t.name}</div>
                    <div style={{ fontSize: 11, color: '#6b7280' }}>{t.blurb}</div>
                  </button>
                ))}
              </div>
              <div style={{ marginTop: 14 }}><span style={lbl}>Accent colour</span>
                <div style={{ display: 'flex', gap: 8 }}>
                  {ACCENTS.map((c) => (<button key={c} onClick={() => set('accent', c)} aria-label={c} style={{ width: 30, height: 30, borderRadius: '50%', background: c, cursor: 'pointer', border: data.accent === c ? '3px solid #111827' : '2px solid #fff', boxShadow: '0 0 0 1px #d1d5db' }} />))}
                </div>
              </div>
            </div>
            <div style={box}>
              <span style={lbl}>Business name</span><input style={inp} value={data.businessName} onChange={(e) => set('businessName', e.target.value)} />
              <span style={lbl}>Tagline</span><input style={inp} value={data.tagline} onChange={(e) => set('tagline', e.target.value)} />
              <span style={lbl}>About</span><textarea style={{ ...inp, minHeight: 90 }} value={data.about} onChange={(e) => set('about', e.target.value)} />
              <span style={lbl}>Phone</span><input style={inp} value={data.phone} onChange={(e) => set('phone', e.target.value)} />
              <span style={lbl}>Email</span><input style={inp} value={data.email} onChange={(e) => set('email', e.target.value)} />
              <span style={lbl}>Location</span><input style={inp} value={data.location} onChange={(e) => set('location', e.target.value)} />
              <span style={lbl}>Opening hours</span><input style={inp} value={data.hours} onChange={(e) => set('hours', e.target.value)} />
              <span style={lbl}>Header image</span>
              <button style={btn('#374151')} onClick={() => pick('hero')}>{data.hero ? 'Change image' : 'Upload image'}</button>
              {data.hero && <button style={{ ...btn('#dc2626'), marginLeft: 8 }} onClick={() => set('hero', '')}>Remove</button>}
            </div>
            <div style={box}>
              <strong>Region and tax</strong>
              <p style={{ fontSize: 12, color: '#6b7280', margin: '4px 0 10px' }}>Currency and language change what your customers see. Card payments work in {STRIPE_CURRENCIES.join(', ')}; other currencies are pay in person.</p>
              <span style={lbl}>Currency</span>
              <select style={inp} value={cur} onChange={(e) => set('currency', e.target.value)}>{CURRENCIES.map((c) => (<option key={c} value={c}>{c}</option>))}</select>
              <span style={lbl}>Language of your site</span>
              <select style={inp} value={data.language || 'en'} onChange={(e) => set('language', e.target.value)}>{LANGUAGES.map((l) => (<option key={l.id} value={l.id}>{l.name}</option>))}</select>
              <span style={lbl}>Tax rate % (VAT, sales tax). Use 0 if you do not charge tax</span>
              <input style={inp} type="number" min="0" max="30" step="0.1" value={data.taxRate ?? 0} onChange={(e) => set('taxRate', e.target.value)} />
              <label style={{ display: 'flex', gap: 8, alignItems: 'center', fontSize: 14, marginBottom: 8 }}>
                <input type="checkbox" checked={data.taxIncluded !== false} onChange={(e) => set('taxIncluded', e.target.checked)} /> My listed prices already include tax
              </label>
              <span style={lbl}>VAT / tax number (shown in your footer, optional)</span>
              <input style={inp} value={data.vatNumber || ''} onChange={(e) => set('vatNumber', e.target.value)} />
            </div>
            <div style={box}>
              <strong>Deposits and WhatsApp</strong>
              {plan === 'starter' && (
                <p style={{ fontSize: 12, color: '#6b7280', margin: '4px 0 10px' }}>These are Professional plan features. <button type="button" style={{ background: 'none', border: 0, color: '#2563eb', cursor: 'pointer', padding: 0, fontSize: 12, textDecoration: 'underline' }} onClick={() => setTab('billing')}>See plans</button></p>
              )}
              <span style={lbl}>Booking deposit (paid by the customer when they book). Needs card payments connected in the Payments tab</span>
              <select style={inp} disabled={plan === 'starter'} value={Number(data.depositPercent) || 0} onChange={(e) => set('depositPercent', Number(e.target.value))}>
                {[0, 10, 20, 25, 30, 50, 100].map((p) => (<option key={p} value={p}>{p === 0 ? 'No deposit' : `${p}% deposit`}</option>))}
              </select>
              <label style={{ display: 'flex', gap: 8, alignItems: 'center', fontSize: 14, marginBottom: 4, opacity: plan === 'starter' ? 0.5 : 1 }}>
                <input type="checkbox" disabled={plan === 'starter'} checked={!!data.whatsappReminders} onChange={(e) => set('whatsappReminders', e.target.checked)} /> Send confirmations and reminders on WhatsApp automatically
              </label>
              <p style={{ fontSize: 12, color: '#6b7280', margin: '0' }}>Automatic WhatsApp needs a Twilio WhatsApp number set up by the platform owner. On every plan you can message a customer yourself with the WhatsApp button on the Bookings tab.</p>
            </div>
          </>)}

          {tab === 'services' && (<>
            {data.services.map((s, i) => (
              <div key={i} style={box}>
                <input style={inp} placeholder="Service name" value={s.name} onChange={(e) => setItem('services', i, { name: e.target.value })} />
                <div style={{ display: 'flex', gap: 8 }}>
                  <input style={inp} type="number" min="0" placeholder={`Price (${sym})`} value={s.price} onChange={(e) => setItem('services', i, { price: e.target.value })} />
                  <input style={inp} placeholder="Duration" value={s.duration} onChange={(e) => setItem('services', i, { duration: e.target.value })} />
                </div>
                <input style={inp} placeholder="Short description" value={s.desc} onChange={(e) => setItem('services', i, { desc: e.target.value })} />
                <label style={{ display: 'flex', gap: 8, alignItems: 'center', fontSize: 14, marginBottom: 8 }}>
                  <input type="checkbox" checked={!!s.negotiable} onChange={(e) => setItem('services', i, { negotiable: e.target.checked })} />
                  Let customers negotiate this price with the AI assistant
                </label>
                {s.negotiable && (
                  <div>
                    <span style={lbl}>Lowest price you would accept, kept private</span>
                    <input style={inp} type="number" min="0" value={s.minPrice || ''} onChange={(e) => setItem('services', i, { minPrice: e.target.value })} />
                    {!(Number(s.minPrice) > 0 && Number(s.minPrice) < Number(s.price)) && <div style={{ fontSize: 12, color: '#dc2626', marginBottom: 8 }}>The lowest price must be above 0 and below the listed price, otherwise negotiation stays off.</div>}
                  </div>
                )}
                <button style={btn('#dc2626')} onClick={() => delItem('services', i)}>Delete</button>
              </div>
            ))}
            <button style={btn()} onClick={() => addItem('services', { name: '', price: 0, duration: '', desc: '', negotiable: false, minPrice: 0 })}>+ Add service</button>
            <p style={{ fontSize: 12, color: '#6b7280' }}>The AI starts near your listed price and steps down. It never goes below your lowest price, and a locked price is signed by the server so it cannot be changed by the customer.</p>
          </>)}

          {tab === 'products' && (<>
            {data.products.map((p, i) => (
              <div key={i} style={box}>
                <input style={inp} placeholder="Product name" value={p.name} onChange={(e) => setItem('products', i, { name: e.target.value })} />
                <input style={inp} type="number" min="0" placeholder={`Price (${sym})`} value={p.price} onChange={(e) => setItem('products', i, { price: e.target.value })} />
                <input style={inp} placeholder="Short description" value={p.desc} onChange={(e) => setItem('products', i, { desc: e.target.value })} />
                {p.image && <img src={p.image} alt="" style={{ width: 90, height: 90, objectFit: 'cover', borderRadius: 8, display: 'block', marginBottom: 8 }} />}
                <button style={btn('#374151')} onClick={() => pick('product', i)}>{p.image ? 'Change photo' : 'Add photo'}</button>
                <button style={{ ...btn('#dc2626'), marginLeft: 8 }} onClick={() => delItem('products', i)}>Delete</button>
              </div>
            ))}
            <button style={btn()} onClick={() => addItem('products', { name: '', price: 0, desc: '', image: '' })}>+ Add product</button>
            <p style={{ fontSize: 12, color: '#6b7280' }}>Customers can add products to a cart and check out. Connect payouts in the Payments tab to take card payments.</p>
          </>)}

          {tab === 'gallery' && (<div style={box}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(100px,1fr))', gap: 8, marginBottom: 12 }}>
              {data.gallery.map((g, i) => (
                <div key={i} style={{ position: 'relative' }}>
                  <img src={g} alt="" style={{ width: '100%', aspectRatio: '1', objectFit: 'cover', borderRadius: 8 }} />
                  <button onClick={() => delItem('gallery', i)} style={{ position: 'absolute', top: 4, right: 4, ...btn('#dc2626'), padding: '2px 8px' }}>×</button>
                </div>
              ))}
            </div>
            <button style={btn()} onClick={() => pick('gallery')} disabled={data.gallery.length >= 12}>+ Add photos ({data.gallery.length}/12)</button>
            <p style={{ fontSize: 12, color: '#6b7280' }}>Photos are compressed automatically.</p>
          </div>)}

          {tab === 'analytics' && (!slug ? needSave : !analytics ? <div style={box}>Loading analytics…</div> : <>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(140px,1fr))', gap: 10, marginBottom: 14 }}>
              {[
                ['Revenue (30 days)', fm(analytics.revenue30)],
                ['Visitors (30 days)', analytics.visitors30],
                ['Bookings (30 days)', analytics.bookings30],
                ['Conversion', analytics.conversion == null ? 'n/a' : `${analytics.conversion}%`],
                ['Repeat customers', analytics.repeatRate == null ? 'n/a' : `${analytics.repeatRate}% (${analytics.repeaters}/${analytics.customers})`],
                ['No-show rate', analytics.noShowRate == null ? 'n/a' : `${analytics.noShowRate}%`],
              ].map(([k, v]) => (<div key={k} style={{ ...box, marginBottom: 0 }}><div style={{ fontSize: 12, color: '#6b7280' }}>{k}</div><div style={{ fontSize: 22, fontWeight: 700 }}>{v}</div></div>))}
            </div>
            <div style={box}><strong>Revenue, last 30 days</strong><Line points={analytics.daily.map((d) => ({ v: d.revenue }))} /></div>
            <div style={box}><strong>Busiest days</strong><Bars items={analytics.byDow} /></div>
            <div style={box}><strong>Busiest times</strong><Bars items={analytics.byHour} color="#7c3aed" /></div>
            <div style={box}>
              <strong>Price suggestions from demand</strong>
              <p style={{ fontSize: 12, color: '#6b7280', margin: '4px 0 10px' }}>Compares bookings for each service over 30 days with your average. These are suggestions, never changed automatically.</p>
              {analytics.suggestions.length === 0 && <div style={{ fontSize: 14 }}>Add services to see suggestions.</div>}
              {analytics.suggestions.map((x) => (
                <div key={x.name} style={{ borderTop: '1px solid #e5e7eb', padding: '10px 0' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, fontWeight: 600 }}>
                    <span>{x.name}</span>
                    <span style={{ color: x.action === 'raise' ? '#059669' : x.action === 'promote' ? '#d97706' : '#6b7280' }}>{x.action === 'raise' ? `Raise to ${fm(x.suggested)}` : x.action === 'promote' ? `Promote or ${fm(x.suggested)}` : 'Keep price'}</span>
                  </div>
                  <div style={{ fontSize: 13, color: '#6b7280' }}>{x.bookings30} bookings in 30 days · {x.reason}</div>
                </div>
              ))}
            </div>
            <div style={box}>
              <strong>AI negotiation</strong>
              <div style={{ fontSize: 14, marginTop: 6 }}>{analytics.negotiated} negotiated bookings ({analytics.negotiatedShare}% of all). Average discount given: {analytics.avgDiscount}%.</div>
            </div>
          </>)}

          {tab === 'bookings' && (<>
            <div style={{ ...box, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
              <span style={{ fontSize: 14 }}>{bookings.length} bookings · {new Set(bookings.map((b) => String(b.contact).toLowerCase())).size} customers</span>
              <a href="/api/site/export?type=bookings" style={{ ...btn('#059669'), textDecoration: 'none' }}>Download Excel</a>
            </div>
            {bookings.length === 0 && <div style={box}>No bookings yet. Share your live site link to get started.</div>}
            {bookings.map((b) => (
              <div key={b.id} style={box}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600 }}>
                  <span>{b.customer}</span>
                  <span>{fm(b.price)}{b.source === 'negotiated' && b.list_price && Number(b.list_price) !== Number(b.price) ? <span style={{ color: '#6b7280', fontWeight: 400, textDecoration: 'line-through', marginLeft: 6 }}>{fm(b.list_price)}</span> : null}</span>
                </div>
                <div style={{ fontSize: 14, color: '#374151' }}>{b.service} · {b.date} {b.time}</div>
                <div style={{ fontSize: 13, color: '#6b7280' }}>{b.contact}</div>
                {b.risk && b.risk.reasons.length > 0 && <div style={{ fontSize: 12, color: '#6b7280' }}>Why: {b.risk.reasons.join(', ')}</div>}
                <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>Booked {b.created} · {b.source === 'negotiated' ? 'negotiated price' : 'website'}</div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
                  <span style={pill(b.status)}>{String(b.status).replace('_', ' ')}</span>
                  {b.risk && <span title={b.risk.reasons.join(', ')} style={{ fontSize: 11, fontWeight: 700, color: RISK_COLOR[b.risk.label], border: `1px solid ${RISK_COLOR[b.risk.label]}`, padding: '1px 8px', borderRadius: 999 }}>No-show risk: {b.risk.label} ({Math.round(b.risk.p * 100)}%)</span>}
                  {b.deposit_amount > 0 && <span style={{ fontSize: 11, fontWeight: 700, color: b.deposit_paid ? '#059669' : '#d97706', border: `1px solid ${b.deposit_paid ? '#059669' : '#d97706'}`, padding: '1px 8px', borderRadius: 999 }}>{b.deposit_paid ? `Deposit paid ${fm(b.deposit_amount)}` : `Deposit unpaid ${fm(b.deposit_amount)}`}</span>}
                  {waLink(b) && <a href={waLink(b)} target="_blank" rel="noreferrer" style={{ ...sm('#25d366'), textDecoration: 'none' }}>WhatsApp</a>}
                  {BOOKING_STATUSES.filter((s) => s !== b.status).map((s) => (<button key={s} style={sm(STATUS_COLOR[s])} onClick={() => setBookingStatus(b.id, s)}>{s.replace('_', ' ')}</button>))}
                </div>
              </div>
            ))}
          </>)}

          {tab === 'orders' && (<>
            <div style={{ ...box, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 8 }}>
              <span style={{ fontSize: 14 }}>{orders.length} orders</span>
              <a href="/api/site/export?type=orders" style={{ ...btn('#059669'), textDecoration: 'none' }}>Download Excel</a>
            </div>
            {orders.length === 0 && <div style={box}>No orders yet.</div>}
            {orders.map((o) => (
              <div key={o.id} style={box}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600 }}><span>#{o.id} · {o.customer}</span><span>{fm(o.total)}</span></div>
                <div style={{ fontSize: 14, color: '#374151' }}>{(o.items || []).map((i) => `${i.qty} × ${i.name}`).join(', ')}</div>
                <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 8 }}>{o.contact} · {o.created}</div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
                  <span style={pill(o.status)}>{o.status}</span>
                  {ORDER_STATUSES.filter((s) => s !== o.status).map((s) => (<button key={s} style={sm(STATUS_COLOR[s])} onClick={() => setOrderStatus(o.id, s)}>{s}</button>))}
                </div>
              </div>
            ))}
          </>)}

          {tab === 'staff' && (!slug ? needSave : <>
            <div style={box}>
              <strong>Staff clock in / out</strong>
              <p style={{ fontSize: 13, color: '#6b7280', margin: '6px 0 10px' }}>Each person gets a private 6-digit code. They open the clock page, enter it and tap Clock in or Clock out.</p>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', marginBottom: 12 }}>
                <code style={{ fontSize: 13, wordBreak: 'break-all', flex: '1 1 200px' }}>{clockUrl}</code>
                <button style={sm('#374151')} onClick={() => copy(clockUrl)}>Copy clock page link</button>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input style={{ ...inp, marginBottom: 0 }} placeholder="Staff name" value={newStaff} onChange={(e) => setNewStaff(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') addStaff(); }} />
                <button style={btn()} onClick={addStaff}>Add</button>
              </div>
            </div>
            {staff.staff.map((s) => (
              <div key={s.id} style={box}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600 }}>
                  <span>{s.name}</span>
                  <span style={{ fontFamily: 'monospace', letterSpacing: 2 }}>{s.code}</span>
                </div>
                <div style={{ fontSize: 13, color: s.working_since ? '#059669' : '#6b7280', margin: '4px 0 8px' }}>{s.working_since ? `Clocked in since ${s.working_since}` : 'Not clocked in'} · {Number(s.hours_7d).toFixed(1)} h in last 7 days</div>
                <button style={sm('#374151')} onClick={() => newCode(s.id)}>New code</button>
                <button style={{ ...sm('#dc2626'), marginLeft: 6 }} onClick={() => removeStaff(s.id)}>Remove</button>
              </div>
            ))}
            {staff.shifts.length > 0 && (
              <div style={box}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                  <strong>Recent shifts</strong>
                  <a href="/api/site/export?type=timesheet" style={{ ...sm('#059669'), textDecoration: 'none' }}>Download timesheet</a>
                </div>
                {staff.shifts.map((h) => (<div key={h.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, padding: '4px 0', borderTop: '1px solid #f3f4f6' }}><span>{h.name} · {h.clock_in}{h.clock_out ? ` → ${h.clock_out.slice(11)}` : ' → now'}</span><span>{Number(h.hours).toFixed(2)} h</span></div>))}
              </div>
            )}
          </>)}

          {tab === 'growth' && (!slug ? needSave : <>
            <div style={box}>
              <strong>Your referral link</strong>
              <p style={{ fontSize: 14, color: '#374151' }}>Share this with other professionals. When they sign up through it, it is counted here.</p>
              {growth ? (<>
                <code style={{ fontSize: 13, wordBreak: 'break-all', display: 'block', marginBottom: 8 }}>{typeof window !== 'undefined' ? `${window.location.origin}/r/${growth.refCode}` : ''}</code>
                <button style={sm('#374151')} onClick={() => copy(`${window.location.origin}/r/${growth.refCode}`)}>{copied ? 'Copied ✓' : 'Copy link'}</button>
                <a style={{ ...sm('#25d366'), textDecoration: 'none', marginLeft: 8 }} target="_blank" rel="noreferrer" href={`https://wa.me/?text=${encodeURIComponent(`Build a booking website in minutes: ${window.location.origin}/r/${growth.refCode}`)}`}>WhatsApp</a>
                <div style={{ display: 'flex', gap: 24, marginTop: 14 }}>
                  <div><div style={{ fontSize: 24, fontWeight: 700 }}>{growth.signups}</div><div style={{ fontSize: 12, color: '#6b7280' }}>sign-ups</div></div>
                  <div><div style={{ fontSize: 24, fontWeight: 700 }}>{growth.published}</div><div style={{ fontSize: 12, color: '#6b7280' }}>published sites</div></div>
                </div>
              </>) : <div style={{ fontSize: 14 }}>Loading…</div>}
            </div>
            <div style={box}>
              <strong>QR code for your site</strong>
              <p style={{ fontSize: 14, color: '#374151' }}>Print it on a business card, window or flyer. Customers scan it and land on your booking page.</p>
              {qr ? (<>
                <img src={qr} alt="QR code for your site" style={{ width: 200, height: 200, display: 'block', marginBottom: 8, background: '#fff', border: '1px solid #e5e7eb', borderRadius: 8 }} />
                <a style={{ ...btn('#059669'), textDecoration: 'none', display: 'inline-block' }} href={qr} download={`${slug}-qr.png`}>Download PNG</a>
              </>) : <button style={btn('#2563eb')} onClick={makeQr}>Generate QR code</button>}
            </div>
            <div style={box}>
              <strong>Your profession page</strong>
              <p style={{ fontSize: 14, color: '#374151' }}>Public pages that rank on Google for each trade. Share the one that matches your work.</p>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {PROFESSIONS.map((p) => (<a key={p.slug} href={`/for/${p.slug}`} target="_blank" rel="noreferrer" style={{ ...sm('#374151'), textDecoration: 'none' }}>{p.name}</a>))}
              </div>
            </div>
          </>)}

          {tab === 'payments' && (!slug ? needSave : <>
            <div style={box}>
              <strong>Get paid by card</strong>
              <p style={{ fontSize: 14, color: '#374151' }}>Your shop currency is <b>{cur}</b>. Change it on the Design tab under Region and tax. We never see or store your bank or card details, the payment partner does.</p>
              {payInfo?.active && (
                <div style={{ color: '#059669', fontWeight: 600 }}>
                  Card payments are live through {payInfo.active === 'paystack' ? 'Paystack' : 'Flutterwave'} ✓
                  <button style={{ ...sm('#6b7280'), marginLeft: 10 }} onClick={turnOffCards}>Turn off</button>
                </div>
              )}
            </div>

            {payInfo?.africa ? (
              (payInfo.paystack.configured || payInfo.flutterwave.configured) ? (
                <div style={box}>
                  <strong>Connect your bank account</strong>
                  <p style={{ fontSize: 13, color: '#6b7280' }}>Customer payments go to your bank, minus a small platform fee and the provider's charges.</p>
                  <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
                    {payInfo.paystack.configured && <button style={btn(payForm.provider === 'paystack' ? '#111827' : '#6b7280')} onClick={() => chooseProvider('paystack')}>Use Paystack</button>}
                    {payInfo.flutterwave.configured && <button style={btn(payForm.provider === 'flutterwave' ? '#111827' : '#6b7280')} onClick={() => chooseProvider('flutterwave')}>Use Flutterwave</button>}
                  </div>
                  {payForm.provider && (<>
                    <span style={lbl}>Bank</span>
                    <select style={inp} value={payForm.bankCode} onChange={(e) => setPayForm({ ...payForm, bankCode: e.target.value, accountName: '', ok: false })}>
                      <option value="">{payForm.busy && !banks.length ? 'Loading banks…' : 'Choose your bank'}</option>
                      {banks.map((bk) => (<option key={bk.code} value={bk.code}>{bk.name}</option>))}
                    </select>
                    <span style={lbl}>Account number</span>
                    <input style={inp} inputMode="numeric" value={payForm.accountNumber} onChange={(e) => setPayForm({ ...payForm, accountNumber: e.target.value.replace(/\D/g, ''), accountName: '', ok: false })} />
                    {payForm.accountName && <div style={{ fontSize: 14, color: '#059669', marginBottom: 8 }}>Account name: <b>{payForm.accountName}</b></div>}
                    <button style={btn('#374151')} disabled={payForm.busy || !payForm.bankCode || payForm.accountNumber.length < 6} onClick={verifyAccount}>Check account name</button>
                    <button style={{ ...btn('#2563eb'), marginLeft: 8 }} disabled={payForm.busy || !payForm.bankCode || payForm.accountNumber.length < 6} onClick={savePayout}>Save and switch on card payments</button>
                    {payForm.msg && <div style={{ fontSize: 13, color: '#dc2626', marginTop: 8 }}>{payForm.msg}</div>}
                  </>)}
                </div>
              ) : (
                <div style={box}><span style={{ fontSize: 14 }}>Card payments in {cur} are not switched on for the platform yet. Customers can still order and pay you in person.</span></div>
              )
            ) : (
              <div style={box}>
                <strong>Connect payouts with Stripe</strong>
                <p style={{ fontSize: 14, color: '#374151' }}>You enter your bank details on Stripe's own secure page. Customer card payments for your products then go straight to your bank.</p>
                {!stripe.configured && <p style={{ fontSize: 13, color: '#dc2626' }}>Card payments are not switched on for the platform yet.</p>}
                {stripe.ready ? (
                  <div style={{ color: '#059669', fontWeight: 600 }}>Payouts connected ✓ Card payments are live on your shop.</div>
                ) : (<>
                  {stripe.connected && <p style={{ fontSize: 13, color: '#d97706' }}>Setup started but not finished. Continue to finish verification.</p>}
                  {!stripe.connected && (<>
                    <span style={lbl}>Country of your business</span>
                    <select style={inp} value={stripeCountry} onChange={(e) => setStripeCountry(e.target.value)}>
                      {[['GB', 'United Kingdom'], ['IE', 'Ireland'], ['FR', 'France'], ['DE', 'Germany'], ['ES', 'Spain'], ['IT', 'Italy'], ['NL', 'Netherlands'], ['BE', 'Belgium'], ['PT', 'Portugal'], ['AT', 'Austria'], ['US', 'United States'], ['CA', 'Canada'], ['AU', 'Australia']].map(([c, n]) => (<option key={c} value={c}>{n}</option>))}
                    </select>
                  </>)}
                  <button style={btn('#2563eb')} onClick={connectStripe} disabled={!stripe.configured}>{stripe.connected ? 'Continue Stripe setup' : 'Connect payouts with Stripe'}</button>
                  <button style={{ ...btn('#6b7280'), marginLeft: 8 }} onClick={loadStripe}>Refresh status</button>
                </>)}
              </div>
            )}
            <p style={{ fontSize: 12, color: '#6b7280' }}>Until payouts are connected, customers can still place orders and pay you in person.</p>
          </>)}

          {tab === 'billing' && (<>
            {billMsg && <div style={{ ...box, color: '#374151' }}>{billMsg}</div>}
            {!billing ? <div style={box}>Loading…</div> : (<>
              <div style={box}>
                <strong>Your plan</strong>
                <div style={{ fontSize: 15, marginTop: 6 }}>
                  {billing.current?.active
                    ? <>{billing.current.plan === 'biz' ? 'Business' : 'Professional'} ({billing.current.cycle}) · {billing.current.status} · renews or ends {new Date(billing.current.expires_at).toLocaleDateString()}</>
                    : 'Starter (free): up to 8 services, 6 photos and 2 staff, with a small GNIS badge on your site'}
                </div>
              </div>
              <div style={box}>
                <div style={{ display: 'flex', gap: 8, marginBottom: 12, alignItems: 'center', flexWrap: 'wrap' }}>
                  <button style={btn(cycle === 'monthly' ? '#111827' : '#6b7280')} onClick={() => setCycle('monthly')}>Monthly</button>
                  <button style={btn(cycle === 'yearly' ? '#111827' : '#6b7280')} onClick={() => setCycle('yearly')}>Yearly (save 20%)</button>
                </div>
                <div style={{ display: 'flex', gap: 8, marginBottom: 12, alignItems: 'center', flexWrap: 'wrap' }}>
                  <label style={{ fontSize: 13, color: '#374151' }}>Your country</label>
                  <select value={billing.region} onChange={(e) => pickRegion(e.target.value)} style={{ padding: '6px 8px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 13 }}>
                    {(billing.regions || []).map((r) => <option key={r.code} value={r.code}>{r.name} ({r.currency})</option>)}
                  </select>
                  <span style={{ fontSize: 12, color: '#6b7280' }}>Prices in {billing.currency}</span>
                </div>
                {[['pro', 'Professional', 'Booking deposits, automatic WhatsApp reminders, up to 30 services and 12 photos, no GNIS badge, up to 5 staff'], ['biz', 'Business', 'Everything in Professional, up to 10 staff, priority support']].map(([key, name, blurb]) => {
                  const p = billing.prices[key][cycle];
                  const f = (n) => { try { return new Intl.NumberFormat(undefined, { style: 'currency', currency: billing.currency, maximumFractionDigits: 0 }).format(n); } catch { return `${billing.currency} ${n}`; } };
                  return (
                    <div key={key} style={{ border: '1px solid #e5e7eb', borderRadius: 10, padding: 14, marginBottom: 10 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, fontWeight: 700 }}><span>{name}</span><span>{f(p.perMonth)}/month</span></div>
                      <div style={{ fontSize: 13, color: '#6b7280', margin: '4px 0 10px' }}>{blurb}{cycle === 'yearly' ? ` · billed ${f(p.amount)} once a year` : ''}</div>
                      <button style={btn('#2563eb')} disabled={!billing.provider} onClick={() => startPlan(key)}>Choose {name}</button>
                    </div>
                  );
                })}
                {!billing.provider && <div style={{ fontSize: 13, color: '#dc2626' }}>Card payments for plans are not switched on for your region yet.</div>}
                {billing.provider && ['paystack', 'flutterwave'].includes(billing.provider) && <div style={{ fontSize: 12, color: '#6b7280' }}>In your region plans are paid for one period at a time. We remind you before your plan ends.</div>}
              </div>
            </>)}
          </>)}
        </div>

        <div style={{ flex: '1 1 420px', minWidth: 0 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#6b7280', marginBottom: 6 }}>LIVE PREVIEW</div>
          <div style={{ border: '1px solid #d1d5db', borderRadius: 12, overflow: 'hidden', maxHeight: '80vh', overflowY: 'auto', background: '#fff' }}>
            <SiteRenderer slug={slug || ''} template={template} data={data} preview payOnline={stripe.ready} showBadge={plan === 'starter'} />
          </div>
        </div>
      </div>
    </div>
  );
}
